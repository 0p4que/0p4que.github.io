# SPECTRUM #

#region ASCIIs
main_title = """
 ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄         ▄  ▄▄       ▄▄ 
▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░▌       ▐░▌▐░░▌     ▐░░▌
▐░█▀▀▀▀▀▀▀▀▀ ▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀▀▀ ▐░█▀▀▀▀▀▀▀▀▀  ▀▀▀▀█░█▀▀▀▀ ▐░█▀▀▀▀▀▀▀█░▌▐░▌       ▐░▌▐░▌░▌   ▐░▐░▌
▐░▌          ▐░▌       ▐░▌▐░▌          ▐░▌               ▐░▌     ▐░▌       ▐░▌▐░▌       ▐░▌▐░▌▐░▌ ▐░▌▐░▌
▐░█▄▄▄▄▄▄▄▄▄ ▐░█▄▄▄▄▄▄▄█░▌▐░█▄▄▄▄▄▄▄▄▄ ▐░▌               ▐░▌     ▐░█▄▄▄▄▄▄▄█░▌▐░▌       ▐░▌▐░▌ ▐░▐░▌ ▐░▌
▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░▌               ▐░▌     ▐░░░░░░░░░░░▌▐░▌       ▐░▌▐░▌  ▐░▌  ▐░▌
 ▀▀▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀▀▀ ▐░█▀▀▀▀▀▀▀▀▀ ▐░▌               ▐░▌     ▐░█▀▀▀▀█░█▀▀ ▐░▌       ▐░▌▐░▌   ▀   ▐░▌
          ▐░▌▐░▌          ▐░▌          ▐░▌               ▐░▌     ▐░▌     ▐░▌  ▐░▌       ▐░▌▐░▌       ▐░▌
 ▄▄▄▄▄▄▄▄▄█░▌▐░▌          ▐░█▄▄▄▄▄▄▄▄▄ ▐░█▄▄▄▄▄▄▄▄▄      ▐░▌     ▐░▌      ▐░▌ ▐░█▄▄▄▄▄▄▄█░▌▐░▌       ▐░▌
▐░░░░░░░░░░░▌▐░▌          ▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌     ▐░▌     ▐░▌       ▐░▌▐░░░░░░░░░░░▌▐░▌       ▐░▌
 ▀▀▀▀▀▀▀▀▀▀▀  ▀            ▀▀▀▀▀▀▀▀▀▀▀  ▀▀▀▀▀▀▀▀▀▀▀       ▀       ▀         ▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀         ▀ 
                                                                                                                                                                                                                        
"""
big_brain = """
⣩⠳⢿⣦⣄⡀⠀⠀⠀⠀⠀⠸⣯⣳⢿⣦⡄⡀⣘⣿⣚⢷⠶⠞⠛⠚⠓⠛⠖⠲⠽⢦⡶⣟⣱⣿⣿⡶⠛⢠⡴⠋⠀⠀⠀⠀⠀⠀⠀⢀
⠛⢿⣷⣮⣝⡿⢿⣶⣦⣄⡀⠀⠈⢻⣷⣽⣿⢿⠛⡉⢠⡀⣆⢐⡢⢘⡠⢍⠒⣄⠲⣄⠐⠈⣡⡿⠋⣰⣾⡟⠀⠀⠀⠀⠀⢀⣀⡤⢖⣫
⠀⠀⠀⠉⠙⠛⠷⣮⣽⣻⢿⣶⣤⣾⣿⡿⠑⣂⢂⠶⡀⠇⠶⣲⢃⡙⣖⢣⠹⣬⡳⣈⠞⡸⠟⠀⢠⠉⠹⢮⡄⣀⣤⠶⣞⡫⢽⠒⠋⠁
⣀⣀⡀⠀⠀⠀⠀⠀⠙⠻⢿⣶⣯⡿⠋⢠⠘⡴⢋⡰⠙⡼⣉⢯⣥⢺⠬⣳⡹⣎⢵⢋⠞⢁⡀⢒⡀⣍⠰⠈⢹⣭⡞⠗⣋⠴⣳⢞⣧⣀
⠉⠉⠛⠛⠶⠻⠿⢿⢶⣦⣾⡿⠋⠀⣬⢃⡟⢠⢆⡙⢇⠶⣩⠌⣻⣎⢳⣎⢗⣚⠎⣁⠴⣊⠵⠊⡔⢬⠂⠩⠄⢺⣅⣠⢏⡓⠄⠊⠒⠭
⠋⠙⠙⠚⠒⠶⣦⣦⣤⣭⠟⠀⠀⡁⠂⠣⠌⠣⢎⡙⠈⠆⢄⠋⠴⣹⢾⡹⢊⣡⠼⣎⡿⢧⡟⣹⠞⠢⠍⠒⠉⠀⣽⡤⢦⡰⢄⡠⣌⢳
⣀⣀⣤⣤⣶⡴⣶⣿⣯⠁⠀⠀⢧⠐⣈⡕⢢⠳⣤⢢⢁⡀⠀⡰⢢⣍⠒⣥⠿⣌⡭⣤⢩⣦⣰⢆⢯⣐⢳⠢⢒⡀⢹⣿⡷⢛⣮⣵⣚⣯
⠻⠿⠶⠷⠾⠷⢿⣿⣿⠀⠀⠆⢈⣐⠧⣬⣣⣷⢮⣳⣍⠲⡅⠆⡽⣞⡿⣤⣍⡙⠻⣜⢫⠷⣍⡿⢌⡓⣊⡵⠈⠀⣼⡿⣇⣀⡁⠉⠁⠀
⠀⠀⠀⠀⠀⠀⣰⣿⡇⢠⣃⠎⣠⠛⡗⣺⣅⢫⢷⡱⢊⡙⢴⣛⢷⣻⠾⣝⣭⡓⢶⣄⣃⠨⣔⠡⢎⢕⣰⠃⡜⠀⣿⣶⣮⣭⣭⣙⣓⣒
⠀⠀⣀⣠⣤⣶⣿⣿⡁⣧⢆⡎⡔⢯⣵⡖⡹⢨⡳⢎⡳⣽⢶⣯⣿⣳⣟⡾⡜⣽⣫⠖⣽⡲⣌⠙⡌⣾⠏⡴⠁⢰⣿⣿⣷⣈⠉⠉⠉⠁
⣿⡟⣟⣯⣽⣷⣿⣏⠱⣍⠞⣴⡘⠮⣰⡴⢻⠽⣙⢯⡳⣮⣿⣳⣩⢗⡼⣶⢏⠲⣭⢳⢌⡳⣬⣛⢰⣿⠆⠀⠌⣾⣷⣭⣛⠻⢿⣶⣤⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣦⡜⢛⣭⣶⢿⣝⣦⣑⡚⣭⡛⢷⡩⢶⢻⡇⢯⠛⡬⢍⢦⢱⢫⢿⡱⢢⣽⠟⢡⣄⡩⢶⠟⣽⣿⠿⣿⣷⣮⣝⡣
⣿⢯⣳⢛⡾⣽⡿⢛⣯⣵⣿⣿⣯⡞⡱⢞⡽⣻⣶⡽⣶⣻⣯⣷⢮⣬⣭⣜⠉⣶⡈⣧⠘⡱⡵⢎⣲⣑⡾⣝⣷⣌⢟⣿⣧⡀⠀⠉⠛⠛
⣟⠦⡁⠋⠀⣡⣶⣿⣿⢯⣿⢰⣿⣿⣷⡾⣄⣷⣽⣟⡿⣿⣿⣿⣳⣟⣾⣻⣧⡘⣯⢹⣆⡔⣛⣮⢷⣿⢱⣯⣿⢿⣷⣎⡿⣿⣷⣄⠀⠀
⠏⣁⣄⢠⣄⢣⣞⣽⣿⣹⠇⣾⣿⣿⣿⣿⣝⣾⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣹⢿⡧⣿⣞⡱⣞⣿⣿⣾⡿⣿⣿⠋⠻⢿⣦⣝⢻⣷⣄
⣾⣷⣞⡷⣮⢷⣯⣿⣿⡯⢼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⣟⣿⡼⣿⣳⡽⣿⣳⣿⣾⡿⠃⠀⠀⠀⠈⠻⣷⣎⡻
⠟⠻⣿⣿⣿⣟⣿⠟⣹⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣻⢷⡯⢿⣧⢹⣷⡛⢿⢿⣿⡟⠁⠀⠀⠀⠀⠀⠀⠈⠻⢷
⠀⠀⠀⠉⠉⠉⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣻⣽⡾⣯⣟⣾⣻⢿⣎⢿⣹⡌⢸⣏⠀⡄⠀⠀⠀⠀⠀⠀⠀⠀⠘
⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣟⡭⣿⣯⣽⣿⣿⣿⣿⣿⣿⣿⣿⣷⣻⣯⢷⣟⣷⣻⢾⣽⣿⢿⡤⣿⡜⣽⠿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣽⣷⣿⣻⣾⢯⣟⣿⡾⣣⣾⣇⢹⣿⡿⣖⢿⣧⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣰⣿⣿⣿⡟⢾⣿⣿⣟⣿⣿⣿⣿⣿⡿⣟⣯⣷⢿⣻⣾⣿⡾⣻⣼⣿⣿⣿⡄⢿⣿⣿⣳⣭⡻⣧⣄⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⣿⣿⢳⣶⣭⣿⣿⣿⣿⣽⣾⡿⣟⣿⣾⣿⡿⢛⣥⣾⣿⣿⣿⣷⣻⣧⠸⣿⣿⣿⣷⡿⣝⣻⣷⣤⡀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠠⣿⣿⣿⣿⣿⣧⡻⣿⣿⣿⣟⣿⣯⣿⡿⢿⢛⣫⣴⣾⣿⣿⣿⣿⣿⣿⣾⣟⣿⡆⢹⣿⢿⣾⣿⣿⣷⣾⠽⣿⣧⡄⠀
⠀⠀⠀⠀⠀⠀⠐⣿⣿⣿⣿⣿⣿⣿⣶⣯⣟⣻⣿⣯⣽⣿⡙⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣿⣻⣷⠀⢻⣯⢾⡽⣿⣾⣿⣿⣳⣟⣿⣆
⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣾⣿⣧⢻⣾⣿⣿⣿⣿⣿⣿⣿⣿⣟⡾⣽⡿⠀⠀⣿⣯⢿⣿⣿⣿⣿⣿⣿⣾⣽
"""
gigachad = """
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⢴⢲⣤⣤⢤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢐⣾⡿⣻⣿⣽⣦⡙⣯⣩⣾⡛⢦⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⠏⣞⣹⣿⣶⣿⣿⣟⣹⣿⣿⡀⣇⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣃⣼⣻⣫⡾⡿⠉⠙⠻⠿⠿⢿⣧⡟⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣿⣿⣫⠾⠁⠀⠀⢃⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⣿⣿⠃⠀⢿⣿⣿⣿⠄⢦⣤⡿⠃⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⠿⣾⣿⠀⢀⠀⠉⠉⣿⡄⠻⡿⠃⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣏⣳⣾⣆⣠⣾⡿⣿⠀⡸⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⡿⣿⠷⣯⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣀⣀⣀⣀⣀⣠⣤⣤⣴⣶⣶⣦⣾⣿⠀⠹⣿⣿⡿⣿⢁⠀⢻⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢀⣴⣾⣿⣿⣿⣿⣿⣿⣭⣿⣿⣿⣿⣿⠟⠉⠙⣿⠀⠀⢸⣿⡿⢿⣮⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⣠⣿⡿⠋⢨⣿⠟⠋⠉⠉⠉⠛⠻⢿⣿⣿⡄⠀⠀⢻⠀⠀⢸⡟⠀⠀⠀⠀⠉⠉⠢⣄⠀⠀⠀⠀⠀⠀⠀⠀
⢰⣿⠋⠀⠀⣾⡇⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⣿⡂⠀⢘⣧⣠⡟⠀⠀⣤⢖⣴⠂⠀⠀⠈⠳⡀⠀⠀⠀⠀⠀⠀
⣾⣇⠀⠀⠀⢸⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣷⣤⣼⣿⣿⣁⣴⣿⣴⠾⠃⠒⠂⢄⡀⠀⠘⠄⡀⠀⠀⠀⠀
⠈⢿⡆⠀⠀⠀⠘⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⠟⠋⠁⠀⠀⠀⠀⠀⠀⠙⢦⡀⠀⠈⠳⡀⠀⠀
⠀⠈⣿⠀⠀⢰⣾⣿⣿⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⣻⣿⡏⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⡆⠀⠀⠘⣄⠀
⠀⣠⡟⠁⣰⣿⡟⡬⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠸⡄
⡞⠋⠀⣠⡿⢿⣆⢡⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⡇
⣅⣠⡾⠋⠀⠀⢻⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⣰⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡀⢀⠀⠀⡏⠀⠀⠀⡸⠀
⠛⠉⠀⠀⠀⠀⠀⠻⣿⣿⣷⣄⣀⠀⠀⢀⣼⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⡴⢋⣶⡿⠀⠀⠑⢦⠀⠀⡇⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⡙⢿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣀⠀⠀⠀⠀⠀⡰⢋⣰⣿⢿⡇⠀⠀⠀⠀⢣⠀⠘⡄
⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⢷⣤⣿⠿⠟⠛⢿⣿⠿⠿⢿⣿⣷⣶⣤⣀⣼⣴⡞⢻⡏⠸⣇⠀⠀⠀⠀⢀⡇⠀⢳
⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⡄⣿⣧⣤⣤⣤⣸⣟⣀⡀⠀⠀⠹⣿⠉⢉⡵⠋⣠⢼⡇⠀⢿⡄⠀⠀⢀⡎⠀⠀⡞
⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡉⣿⠁⠀⠀⠀⢹⣿⠉⠛⠛⠒⠛⢻⡀⢈⡤⢊⡇⠈⢿⣶⠞⢷⡀⠀⢾⠀⠀⠈⡄
⠀⠀⠀⠀⠀⠀⠀⢀⣾⡏⠳⣿⣶⣦⣤⠶⢾⡿⠲⠦⠤⠤⠤⢾⡁⢈⠔⢉⠇⠀⠈⢿⣷⢼⣿⡆⠀⢣⠀⠀⣸
"""
speech_100 = """
                                                  $$\               $$\   $$$$$$\   $$$$$$\  
                                                  $$ |            $$$$ | $$$ __$$\ $$$ __$$\ 
 $$$$$$$\  $$$$$$\   $$$$$$\   $$$$$$\   $$$$$$$\ $$$$$$$\        \_$$ | $$$$\ $$ |$$$$\ $$ |
$$  _____|$$  __$$\ $$  __$$\ $$  __$$\ $$  _____|$$  __$$\         $$ | $$\$$\$$ |$$\$$\$$ |
\$$$$$$\  $$ /  $$ |$$$$$$$$ |$$$$$$$$ |$$ /      $$ |  $$ |        $$ | $$ \$$$$ |$$ \$$$$ |
 \____$$\ $$ |  $$ |$$   ____|$$   ____|$$ |      $$ |  $$ |        $$ | $$ |\$$$ |$$ |\$$$ |
$$$$$$$  |$$$$$$$  |\$$$$$$$\ \$$$$$$$\ \$$$$$$$\ $$ |  $$ |      $$$$$$\\$$$$$$  /\$$$$$$  /
\_______/ $$  ____/  \_______| \_______| \_______|\__|  \__|      \______|\______/  \______/ 
          $$ |                                                                               
          $$ |                                                                               
          \__|                                                                               
"""
rare_pepe = """
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣴⡶⠟⠛⠉⠉⠉⠙⠛⠷⣦⣀⠀⢀⣠⣤⣶⠶⠾⠿⠶⣶⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡾⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⡟⠉⠁⠀⠀⠀⠀⠀⠀⠙⢿⣄⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣾⠏⠀⠀⢀⣤⣴⠶⠟⠛⠛⠛⠛⠶⢶⣤⣼⣿⡀⢀⣀⣀⣀⣀⣀⣀⣀⣈⣿⡆⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣾⠏⠀⠀⠀⠛⠉⠀⠀⠀⠀⠀⠀⣀⣀⣠⣬⣽⣿⣿⡛⠋⠉⠉⣉⣉⣉⣉⣿⣿⣿⣶⣦⣄⡀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣾⠏⠀⠀⠀⠀⠀⠀⠀⣀⣤⣶⢶⣻⣯⣽⣿⣿⣿⣿⣿⣿⣷⣄⠀⣛⣉⣩⣭⣯⣿⣿⣿⣭⣝⣻⣦⠀⠀
⠀⠀⠀⠀⠀⠀⢀⣤⣶⠟⠁⠀⠀⠀⠀⠀⣀⣶⢟⣻⣽⡾⠟⠋⠉⠀⢀⣀⣀⣠⣤⣭⣽⣿⡟⠛⣉⣉⣭⣴⣶⣤⣤⣬⣭⣿⣿⣦⠀
⠀⠀⠀⠀⠀⢠⡿⠋⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⣿⣉⣁⣀⣤⣴⢶⣿⠿⣿⣿⣯⡉⠀⠈⣿⡿⠛⠛⠉⢉⣿⡛⣿⢿⣷⡄⠉⠙⣿⡆
⠀⠀⠀⠀⣠⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⢹⣿⣿⣭⣁⠀⣼⣿⡶⣿⣁⣸⣿⣤⣾⣿⣤⣀⣀⣀⣾⣿⣻⣧⣀⣿⣿⣤⣶⡟⠁
⠀⠀⢀⣴⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠋⠈⠉⠉⠛⠛⠛⠛⠛⠛⢋⣿⡟⠋⠀⠀
⠀⢀⣾⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⣉⣭⣿⠿⠋⠀⠀⠰⢷⣦⣄⣠⣤⣤⣤⣤⣶⠟⠋⠀⠀⠀⠀
⢀⣾⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠾⠛⠛⠉⠀⠀⠀⠀⠀⠀⠀⠈⠙⠿⣯⠉⠀⠈⠻⣦⡀⠀⠀⠀⠀
⢸⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣷⡄⠀⠀⠀
⢸⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣤⣤⣴⣦⣤⣤⣤⣤⣀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣤⣤⡾⣷⡄⠀⠀
⠀⢿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⡟⠉⢀⣤⣤⣤⣄⣀⣀⣉⠉⠙⠛⠻⠷⠶⠶⠶⠶⠶⠶⠾⠿⠟⠛⠛⠋⠉⠀⢀⣼⡇⠀⠀
⠀⠘⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⠸⣧⣀⣀⣉⣀⣈⣉⣉⣙⡛⠻⠿⠶⠶⠶⣦⣤⣤⣤⣤⣤⣤⣤⣤⣤⡴⠶⠶⢾⡟⠋⠀⠀⠀
⠀⠀⠘⢿⣦⡀⠀⠀⠀⠀⠀⠀⠀⢿⣦⣈⣛⠛⠋⠉⠉⠉⠉⠙⠛⠛⠿⠶⠶⣶⣤⣤⣤⣤⣀⣀⣀⣀⣀⣀⣀⣀⣤⡾⠃⠀⠀⠀⠀
⠀⠀⠀⠀⠙⣿⣶⣤⣀⡀⠀⠀⠀⠀⠉⠙⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠉⠉⣉⣿⠿⠋⠉⠉⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠙⠻⢿⣿⣿⣷⣶⣤⣤⣄⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣠⣤⣤⣶⠾⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠛⠛⠿⠿⣯⣿⣿⣛⣛⣛⣛⣛⣛⣛⣛⣛⣛⣛⣛⣿⡿⠟⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉⠉⠛⠛⠛⠋⠉⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
"""
tesla = """
   __---~~~~--__                      __--~~~~---__
 `\---~~~~~~~~\\                    //~~~~~~~~---/'  
   \/~~~~~~~~~\||                  ||/~~~~~~~~~\/ 
               `\\                //'
                 `\\            //'
                   ||          ||      
         ______--~~~~~~~~~~~~~~~~~~--______              
    ___ // _-~                        ~-_ \\ ___  
   `\__)\/~                              ~\/(__/'          
    _--`-___                            ___-'--_        
  /~     `\ ~~~~~~~~------------~~~~~~~~ /'     ~\        
 /|        `\         ________         /'        |\     
| `\   ______`\_      \------/      _/'______   /' |          
|   `\_~-_____\ ~-________________-~ /_____-~_/'   |  
`.     ~-__________________________________-~     .'       
 `.      [_______/------|~~|------\_______]      .'
  `\--___((____)(________\/________)(____))___--/'           
   |>>>>>>||                            ||<<<<<<|
"""
police = """
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⡿⠿⠿⠿⠛⢁⣠⣤⣤⣄⡈⠛⠿⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⠟⠁⠀⠀⠀⠀⠀⢿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠈⠻⣿⣿⣿⣿⣿
⣿⣿⣯⠁⠀⠀⠀⠀⠀⠀⠀⠀⠈⢿⣿⣿⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠈⣽⣿⣿
⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⢈⣙⣋⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣿⣿⣿
⣿⣿⣿⣿⣦⣤⡤⠴⠶⠾⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠷⠶⠦⢤⣤⣴⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣹⣿⣿⣿⣿⣿
⣿⣿⣿⠋⢸⡟⢷⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⡾⢻⡇⠙⣿⣿⣿
⣿⣿⣿⡆⢸⣇⠀⢸⣿⣿⣿⣶⣶⣶⣶⣶⣶⣶⣶⣿⣿⣿⡇⠀⣸⡇⢰⣿⣿⣿
⣿⣿⣿⣿⣌⣿⠀⠈⠻⣿⣿⣿⣿⠿⠀⠀⠿⣿⣿⣿⣿⠟⠁⠀⣿⣡⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀⣀⣴⣦⣀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣆⠀⠒⠲⠿⠿⠛⠛⠿⠿⠖⠒⠀⣰⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣤⣀⠀⠀⠀⠀⠀⠀⣀⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
"""
elon_musk = """
.
⠄⠄⠄⠄⠄⠄⠄⠄⣠⣤⣶⣶⣶⣶⣤⣤⣤⣀
⠄⠄⠄⠄⠄⣠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣆
⠄⠄⠄⢀⣤⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄
⠄⠄⢀⣽⣿⣿⡿⠛⠉⠉⠉⠉⠉⠉⠉⠉⠛⠻⢿⣿⣿⣷⡀
⠄⠄⣾⣿⣿⠏⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠘⣿⣿⣷
⠄⠄⠁⠉⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⢻⣿⣿⡇
⠄⢠⣯⡠⠞⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⢹⣿⡇
⠄⢸⣿⠁⠄⠄⣠⡶⠛⠛⠷⣄⠄⠄⠄⠄⣠⣤⣤⠄⠄⠄⣿⡇
⠄⠘⡏⠄⠄⠰⣿⡿⠿⠖⠶⢿⠇⠄⠄⣤⣤⣤⣀⠄⠄⠄⣿⡇
⢸⢶⡇⠄⠄⠄⠄⠈⠄⠄⠄⠄⠄⠄⠄⠐⠤⠄⠉⠃⠄⠄⣿⠃
⠘⣾⡇⠄⠄⠄⠄⠄⠄⠄⢀⣴⣇⠄⠄⠄⠄⠄⠄⠄⠄⠄⢿⡆
⠄⠋⠁⠄⢀⣤⣄⠄⠄⠄⠸⣿⣿⡷⠶⠄⠄⠄⠄⠄⠄⠰
⠄⠄⠄⠄⢸⡿⠟⠄⠄⡀⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄
⠄⠄⠄⠄⣸⣷⡀⠄⠸⣿⣿⠿⠟⠛⠻⠦⠄⠄⠄⠄⠄
⢀⣀⠄⣼⣿⣿⣿⣦⠄⠈⠻⠿⠶⠖⠄⠄⠄⠄⠄⠄⠄
⣿⣿⡄⢹⣿⣿⣿⣿⣦⡀⠄⠄⠄⠄⠄⠄⠄⠄⢀⠔
⣿⣿⣿⡜⣿⣿⣿⣿⣿⣿⣿⣶⣦⣤⣤⣴⣶⠟⠉
⣿⣿⣿⣿⡌⢿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠁
⣿⣿⣿⣿⣿⣆⠙⣿⣿⣿⣿⣿⣿⠟⠄⠄⢀⣶⡀
⣿⣿⣿⣿⣿⣿⣧⣈⢛⠋⠙⣿⣿⠄⠄⠄⣼⣿⣿⣄
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣆⠄⠄⠄⠄⠄⢸⣿⣿⣿⣆
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡀⠄⠄⠄⠄⠄⠻⠛⠻⠿
⠄⠄⠄⠄⠄⢀⣀⣀
⢠⠴⣶⠶⠶⠎⢹⡟
⢀⣴⣿⣤⠄⠄⣼⡇⠄⣠⡶⠻⣶⣤⣴⡆⣴⢺⣆⠄⢀⡄
⠄⣸⡇⠄⠄⠄⣿⠄⣼⣿⠄⢀⡿⠄⢸⣿⠃⠄⣿⣠⠞
⠄⠙⠛⠛⠉⠄⠙⠋⠁⠙⠛⠋⠄⠄⠘⠃⠄⠄⠙⠉
⠄⢠⡀⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⢠⣤⡄
⠄⠘⣷⠄⠄⢀⣿⡇⠄⠄⠄⠄⣀⠄⠄⣀⡀⠄⣹⠇⢀⡀
⠄⢸⣿⣆⢀⡾⣿⠁⢸⡟⠄⣸⡟⠄⣠⣿⠁⣠⣿⡴⠋⠁⢀⡆
⢀⣿⠄⠙⠋⢀⣿⠄⢾⣇⡴⠻⣧⡴⣣⡼⡟⢱⡏⠻⣦⡴⠋
⠄⠉⠄⠄⠄⠄⠛⠄⠈⠉⠄⠄⠉⠄⠛⠚⠁⠈⠁
"""
end_credits = """
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣴⠶⠶⣶⠶⠶⠶⠶⠶⠶⠶⠶⠶⢶⠶⠶⠶⠤⠤⠤⠤⣄⣀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣠⡾⠋⠀⠀⠊⠀⠀⠀⠀⠀⠀⠀⠀⠒⠒⠒⠀⠀⠀⠀⠤⢤⣤⣄⠉⠉⠛⠛⠷⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣰⠟⠀⠀⠀⠀⠀⠐⠋⢑⣤⣶⣶⣤⡢⡀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣄⡂⠀⠀⠶⢄⠙⢷⣤⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣸⡿⠚⠉⡀⠀⠀⠀⠀⢰⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⢢⠀⠀⡀⣰⣿⣿⣿⣿⣦⡀⠀⠀⠡⡀⢹⡆⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢀⣴⠏⠀⣀⣀⣀⡤⢤⣄⣠⣿⣿⣿⣿⣻⣿⣿⣷⠀⢋⣾⠈⠙⣶⠒⢿⣿⣿⣿⣿⡿⠟⠃⠀⡀⠡⠼⣧⡀⠀⠀⠀⠀⠀⠀
⠀⠀⢀⣴⣿⢃⡴⢊⢽⣶⣤⣀⠀⠊⠉⠉⡛⢿⣿⣿⣿⠿⠋⢀⡀⠁⠀⠀⢸⣁⣀⣉⣉⣉⡉⠀⠩⡡⠀⣩⣦⠀⠈⠻⣦⡀⠀⠀⠀⠀
⠀⢠⡟⢡⠇⡞⢀⠆⠀⢻⣿⣿⣷⣄⠀⢀⠈⠂⠈⢁⡤⠚⡟⠉⠀⣀⣀⠀⠈⠳⣍⠓⢆⢀⡠⢀⣨⣴⣿⣿⡏⢀⡆⠀⢸⡇⠀⠀⠀⠀
⠀⣾⠁⢸⠀⠀⢸⠀⠀⠀⠹⣿⣿⣿⣿⣶⣬⣦⣤⡈⠀⠀⠇⠀⠛⠉⣩⣤⣤⣤⣿⣤⣤⣴⣾⣿⣿⣿⣿⣿⣧⠞⠀⠀⢸⡇⠀⠀⠀⠀
⠀⢹⣆⠸⠀⠀⢸⠀⠀⠀⠀⠘⢿⣿⣿⣿⣿⣿⣿⣟⣛⠛⠛⣛⡛⠛⠛⣛⣋⡉⠉⣡⠶⢾⣿⣿⣿⣿⣿⣿⡇⠀⠀⢀⣾⠃⠀⠀⠀⠀
⠀⠀⠻⣆⡀⠀⠈⢂⠀⠀⠀⠠⡈⢻⣿⣿⣿⣿⡟⠁⠈⢧⡼⠉⠙⣆⡞⠁⠈⢹⣴⠃⠀⢸⣿⣿⣿⣿⣿⣿⠃⠀⡆⣾⠃⠀⠀⠀⠀⠀
⠀⠀⠀⠈⢻⣇⠀⠀⠀⠀⠀⠀⢡⠀⠹⣿⣿⣿⣷⡀⠀⣸⡇⠀⠀⣿⠁⠀⠀⠘⣿⠀⠀⠘⣿⣿⣿⣿⣿⣿⠀⠀⣿⡇⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠹⣇⠀⠠⠀⠀⠀⠀⠡⠐⢬⡻⣿⣿⣿⣿⣿⣷⣶⣶⣿⣦⣤⣤⣤⣿⣦⣶⣿⣿⣿⣿⣿⣿⣿⠀⠀⣿⡇⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠹⣧⡀⠡⡀⠀⠀⠀⠑⠄⠙⢎⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⠀⢿⡇⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠈⠳⣤⡐⡄⠀⠀⠀⠈⠂⠀⠱⣌⠻⣿⣿⣿⣿⣿⣿⣿⠿⣿⠟⢻⡏⢻⣿⣿⣿⣿⣿⣿⣿⠀⢸⡇⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⢮⣦⡀⠂⠀⢀⠀⠀⠈⠳⣈⠻⣿⣿⣿⡇⠘⡄⢸⠀⠀⣇⠀⣻⣿⣿⣿⣿⣿⡏⠀⠸⡇⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⢶⣤⣄⡑⠄⠀⠀⠈⠑⠢⠙⠻⢷⣶⣵⣞⣑⣒⣋⣉⣁⣻⣿⠿⠟⠱⠃⡸⠀⣧⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠻⣷⣄⡀⠐⠢⣄⣀⡀⠀⠉⠉⠉⠉⠛⠙⠭⠭⠄⠒⠈⠀⠐⠁⢀⣿⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠷⢦⣤⣤⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣒⡠⠄⣠⡾⠃⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠙⠛⠷⠶⣦⣤⣭⣤⣬⣭⣭⣴⠶⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀

SPECTRUM 

Lead Programmer - Ryan Simpson
Lead Writer/Support Programmer - Brian Jama
Lead Concept Planner - Darren Murphy
Lead Designer - Grzegorz Ogrodnik
"""
#endregion

#region imports
from os.path import isfile
from datetime import datetime
from random import randint
from time import sleep
from webbrowser import open as web
#endregion

#region functions
common_log = ["ValueError - user entered something other than an integer"]

def log(data): 
    time = datetime.now() 
    file = open("spectrum_log.txt", "a") 
    file.write("[" + str(time.day) + "/" + str(time.month) + "/" + str(time.year) + " at " + str(time.hour) + ":" + str(time.minute) + "]: " + str(data) + "\n")
    file.close()

if isfile("spectrum_log.txt"):
    log("Program started")
else:
    log("New logfile created")
    log("Program started")

def game_over(reason):
    print(f"GAME OVER!\n {reason}")
    log("Program quit (game over)")
    quit()

def quiz(length):
    score = 0
    if str(input("What is the sum of the internal angles of a triangle? ")) == str(180):
        score += 1
        print(f"Correct! Score:{score}")
    else:
        print(f"Incorrect. Score:{score}")
    ans_temp = str(input("What is bitcoin? ")).lower()
    if ans_temp == "cryptocurrency" or ans_temp == "crypto":
        score += 1
        print(f"Correct! Score:{score}")
    else:
        print(f"Incorrect. Score:{score}")
    if str(input("Who invented the planet saturn? ")).lower() == "galileo":
        score += 1
        print(f"Correct! Score:{score}")
    else:
        print(f"Incorrect. Score:{score}")
    if str(input("What is the square root of -1? ")).lower() == "i":
        score += 1
        print(f"Correct! Score:{score}")
    else:
        print(f"Incorrect. Score:{score}")
    if str(input("What is a 50 sided shape called? ")).lower() == "pentacontagon":
        score += 1
        print(f"Correct! Score:{score}")
    else:
        print(f"Incorrect. Score:{score}")
    if length == "short":
        if score > 3:
            print("Success you passed! Your father is ashamed and you have won!")
        else:
            game_over("You failed miserably, considering your intelligence you should be ashamed...")
    else:
        if str(input("In which UK country is snowdonia located? ")).lower() == "wales":
            score += 1
            print(f"Correct! Score:{score}")
        else:
            print(f"Incorrect. Score:{score}")
        if str(input("What is marie curie's maiden name? ")).lower() == "sklodowska":
            score += 1
            print(f"Correct! Score:{score}")
        else:
            print(f"Incorrect. Score:{score}")
        if str(input("How many stars are on the european flag? ")) == str(12):
            score += 1
            print(f"Correct! Score:{score}")
        else:
            print(f"Incorrect. Score:{score}")
        if str(input("What ethnicity was nikola tesla? ")).lower() == str("serbian"):
            score += 1
            print(f"Correct! Score:{score}")
        else:
            print(f"Incorrect. Score:{score}")
        if str(input("What country is completely surrounded by south africa? ")).lower() == "lesotho":
            score += 1
            print(f"Correct! Score:{score}")
        else:
            print(f"Incorrect. Score:{score}")
        if score > 7:
            print("Success you passed! Given your total idiocy that is very surprising!")
            print("Your father hangs his head in shame.")
        else:
            game_over("You failed miserabley, go home loser...")
#endregion

#region player profile class
class player_profile:
    def __init__(self, name=None, age=None, gender=None, intelligence=None, strength=None, charisma=None, autism=None):
        self.name = name
        self.age = age
        self.gender = gender
        self.intelligence = intelligence
        self.strength = strength
        self.charisma = charisma
        self.autism = autism
    def stats(self):
        return (
            f"""
            -----------------------------------------------------------------
            ID CARD:
            NAME: {self.name} | AGE: {self.age} | GENDER: {self.gender}
            INTELLIGENCE: {self.intelligence}
            STRENGTH: {self.strength}
            CHARISMA: {self.charisma}
            AUTISM: {self.autism}
            -----------------------------------------------------------------
        """
        )
    def add_points(self, attribute, amount):
        if attribute == "intelligence":
            self.intelligence += amount
            print(f"+ {amount} intelligence")
        elif attribute == "strength":
            self.strength += amount
            print(f"+ {amount} strength")
        elif attribute == "charisma":
            self.charisma += amount
            print(f"+ {amount} charisma")
        elif attribute == "autism":
            player.autism += amount
            print(f"+ {amount} autism")
        elif attribute == "all":
            player.intelligence += amount
            player.strength += amount
            player.charisma += amount
            player.autism += amount
            print(f"+ {amount} ON ALL STATS")
        else:
            raise RuntimeError

#endregion

print(main_title)

#region player profile setup
log("Gathering player data...")
player = player_profile()

print("Welcome to spectrum, an autistic sci-fi adventure game. To get started, fill out your player profile.")
player.name = input("Enter your name: ").capitalize()
while True:
    try:
        player.age = int(input("Enter your age: "))
        break
    except ValueError:
        log(common_log[0])
        print("You may only enter your age as an integer")
player.gender = input("Enter your gender: ")
print(f"Okay {player.name}, now you must choose your skillsets, you have 10 points to allocate. Please choose which skills you would like to allocate points to. Each skill has a maximum of 5 skill points that can be allocated to it and there are 4 skills, so choose wisely.")

skill_points = 10
skills_allocated = [False, False, False]
print(f"Skill points remaining: {skill_points}")

while skills_allocated[0] != True:
    try:
        player.intelligence = int(input("Allocate points to intelligence (MIN 0, MAX 5): "))
        if player.intelligence >= 0 and player.intelligence <= 5:
            print(f"{player.intelligence} points allocated to intelligence")
            skill_points -= player.intelligence
            skills_allocated[0] = True
        else:
            print("Please enter a value between 0 and 5")                    
    except ValueError:
        log(common_log[0])
        print("You may only enter an integer value")

print(f"{skill_points} skill points remaining")

while skills_allocated[1] != True:
    try:
        player.strength = int(input("Allocate points to strength (MIN 0, MAX 5): "))
        if player.strength >= 0 and player.strength <= 5:
            print(f"{player.strength} points allocated to strength")
            skill_points -= player.strength
            skills_allocated[1] = True
        else:
            print("Please enter a value between 0 and 5")                    
    except ValueError:
        log(common_log[0])
        print("You may only enter an integer value")

print(f"{skill_points} skill points remaining")

if skill_points > 0:
    while skills_allocated[2] != True:
        try:
            player.charisma = int(input("Allocate points to charisma (MIN 0, MAX 5): "))
            if player.charisma < 0 or player.charisma > 5:
                print("Please enter a value between 0 and 5")
            elif player.charisma > skill_points:
                print("You don't have enough skill points for that")
                print(f"You have {skill_points} skill points remaining")
            elif player.charisma >= 0 and player.charisma <= 5 and player.charisma <= skill_points:
                print(f"{player.charisma} points allocated to charisma")
                skill_points -= player.charisma
                skills_allocated[2] = True
        except ValueError:
            log(common_log[0])
            print("You may only enter an integer value")
else:
    player.charisma = 0
    player.autism = 0

if skill_points > 0:
    if skill_points > 5:
        print("You have more than 5 points remaining. Bad decision making. 5 points will be allocated to autism and the rest are lost forever!")
        player.autism = 5
    else:
        print(f"Your remaining {skill_points} skill points have been automatically allocated to autism")
        player.autism = skill_points
else:
    player.autism = 0

log("Player details recorded")

#endregion

print("You have allocated all your skill points!\n")
print(player.stats())

#region breaking in to the computer
log("Game beginning")
print("""
On the Musk estate, San Antonio, Texas, you awake to the sound of birds chirping a quick glimpse at your phone alerts you that the time is 10am, a perfect time to start the day you think to yourself. 
As you lay there you decide to take a few minutes to gather yourself while browsing /r/all to get your morning information dump, you decide it’s time to interact with your family.
As you exit your bedroom you find the house to be strangely quiet, this is unusual as the house around this time is usually filled with life, you call out to anyone within earshot, “GOOD MORNING!”
you shout only to be met with silence, you decide to not overthink it and just shrug it off as you being the only one in the house this morning. 
You use this alone time to try and gain access to your father’s computer knowing he had recently bought a rare pepe NFT worth $420,000, on your way to your fathers bedroom you take the time to
examine a family picture there’s you, X Æ A-12 and your father Elon Musk.

""")
print("Upon entering your father's room to gain access to his rare pepe folder to try to flip them into nft's you decide to do some innocent snooping into his computer")
print("Upon pressing the enter key, you are met with 'enter password' screen. You have 3 tries, what will you enter? (password hint: facebookfounder69)")
successful_guess = False
for i in range(3):
    if input("Please enter the password: ").lower() == "zuckerberg69":
        print("Access Granted")
        successful_guess = True
        break
    else:
        print("Access Denied")

if successful_guess == False:
    print("After a few tries, you use your intuition and realise that the password is, 'zuckerberg69'")
    print("But you took so many tries the computer decided to prank you...")
    sleep(2)
    web("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
else:
    print("In less than 3 tries, you guessed the password. You are a genius.")

print("Inside your fathers PC you find 4 files, which one do you choose? File (1,2,3,4)...")
while True:
    try:
        file_select = int(input("Select a file:"))
        if file_select > 4 or file_select <1:
            raise ValueError
        else:
            if file_select == 1:
                print(big_brain)
                print("You figure out File 1 is neuralink plans, could be useful")
                player.add_points("intelligence", 1)
            elif file_select == 2:
                print(gigachad)
                print("You figure out File 2 is a guide to inject gigachad steroids, maybe I should order some too")
                player.add_points("strength", 1)
            elif file_select == 3:
                print(speech_100)
                print("File 3 is a motivional speech book")
                player.add_points("charisma", 1)
            elif file_select == 4:
                print(rare_pepe)
                print("SUCCESS RARE PEPE!!!")
                player.add_points("autism", 1)
            sleep(1)
            break
            
    except ValueError:
        print("please enter an intger between 1 - 4")
        log(common_log[0])

#endregion

#region discovering elons plans and gambling
sleep(5)
print("After searching through your dad's files for a bit you come accross something strange.")
print("A file called secret_planz.txt. Feeling suspicious you open the file... and are horrified.")
print("There in great detail are \"Elon's plans to destroy the world! Using a device called the 'Ion Cannon'\"")
print("The file clearly shows a world destruction plan, followed by a plan to build an off-planet utopia for the super rich to live on while everyone else is made to suffer!\n")
print("You now decide to go and confront your dad, but first you do some online gambling aka trading some crypto...")
input("Press enter to gamble in a risky fashion...\n")

luck = randint(1, 5)
if luck > 0 and luck < 5:
    print("You lost money and learned that crypto is a bit of a scam sometimes")
    player.add_points("intelligence", 1)
else:
    print("You got really lucky!")
    player.add_points("all", 1)

#endregion

#region heading to tesla headquarters
sleep(2)
print(tesla)
print("Now you begin to make your way to tesla headquarters to confront your dad.")
print("You hop in your tesla and speed off towards austin texas")
sleep(5)
#endregion

#region police stopping you
print(police)
print("As you enter the Austin, Texas speed way doing 180 mph in you Tesla Model S. Hyperfocused on confronting your dad you forget the speed limit, suddenly you hear the sirens of a texas highway patrol.\n You are approached by a state trooper and he proceeds to question you and asks for your ID;")
print(player.stats())

if player.intelligence > 1 or player.charisma > 1:
    print("Due to your adequate level of intelligence and charisma you were able to avoid being detained.")
    tesla_entry = False
    print("You arrive at tesla headquarters, now you need to get in somehow")
    while tesla_entry == False:
        try:
            tesla_choice = int(input("Please select which skill to use 1,2,3 or 4? (1 - Intelligence| 2 - Strength| 3 - Charisma| 4 - Autism: "))
            print("\n")
            if tesla_choice > 4 or tesla_choice <1:
                raise ValueError
            else:
                if tesla_choice == 1:
                    if player.intelligence < 3:
                        print("Intelligence isn't high enough. You attempt to use big electrochemistry words but only make a fool out of yourself misprouncing words and misunderstanding properties then it's revealed that the receptionist is a engineering masters(Msc) student doing a placement in battery technologies at Tesla, please select another option.")
                        pass
                    else:
                        print("You manage to elude the guards on the way in due to your high intelligence and great understanding of tesla's technology.")
                    tesla_entry = True
                elif tesla_choice == 2:
                    if player.strength < 3:
                        print("Strength isn't high enough. You attempt to apply a sleeper hold only for the guard to shake you off andc slam you to the ground, please select another option.")
                        pass
                    else:
                        print("You decide to flex your strength and subdue the security guard using an anaconda choke.")
                        print("- 1 Intelligence")
                        player.intelligence -= 1
                        tesla_entry = True
                elif tesla_choice == 3:
                    if player.charisma < 3:
                        print("Charisma isn't high enough. You attempt to speak but mess up your words stuttering and contradicting yourself so you fail miserably.")
                        pass
                    else:
                        print("You speak to the receptionist and use your family connection to gain entry.")
                        tesla_entry = True
                elif tesla_choice == 4:
                    if player.autism < 3:
                        print("Autism isn't high enough. You try to remember that code you thought you saw your father input but keep getting a 'incorrect code' message on the keypad ... people at the front office get suspicious and ask you to leave, please select another option.")
                        pass
                    else:
                        print("Using your autism you remember the code you once saw your father input")
                        tesla_entry = True
                print("\n")
        except ValueError:
                print("Please input a number between 1-4")
                pass
else:
    log("Game over")   
    game_over("Intelligence and Charisma was not high enough. We told you to allocate them carefully in the beginning!")

#endregion

#region in tesla offices
print("After successfully gaining entry to the tesla headquarters, you make your way to your fathers office")
print("When you get there you find a keypad that you do not know the code to.")
print("Upon looking closer at the keypad you realise it is a maths question")
num1 = randint(1, 100)
num2 = randint(1, 10)
answer = num1 * num2

if player.intelligence > 2:
    print("Due to your high intelligence, you get 6 attempts!")
    tries_remaining = 6
elif player.autism > 2:
    print("Due to your high levels of autism, you get 11 attempts!")
    tries_remaining = 11
elif player.charisma > 2:
    print("Due to your high levels of charisma you know how to talk to a keypad ( ͡° ͜ʖ ͡°), you get 5 attempts")
    tries_remaining = 5
elif player.strength > 2:
    print("Due to strength being your only good attribute, you get the standard 4 tries. Strength is useless when it comes to maths.")
    tries_remaining = 4
else:
    game_over("somehow you have literally no useful attributes in regards to this task. which is impossible by now how did you even")
while True:
    tries_remaining -= 1
    try:
        user_input = int(input(f"What is {num1} x {num2}: "))
        if user_input == answer and tries_remaining > 0:
            print("Correct!")
            break
        elif tries_remaining > 0 and user_input != answer:
            print(f"Incorrect, you have {tries_remaining} lives left...")
    except ValueError:
        print(f"Incorrect, you have {tries_remaining} lives left...")
    if tries_remaining == 0:
            game_over("You didn't get the maths question right, tesla security was alerted to your presence and you where beaten by your dad")



#endregion

#region navigating inside
print("After entering the building you start to navigate your way around the Tesla headquaters using the memory of when your father showed you around on a bring your child to work day a few years ago. While making your way to the CEO office you see a door with 'ONLY CERTIFIED PERSONEL MAY ENTER' written boldly on the door beside the door is heavy security armed with flamethowers which you wisely decide to avoid, you continue your journey towards your father's office...")

if randint(1, 10) == 7:
    print("On your way towards the office you notice a room with a golden handle out of curiosity you decide to enter, to your bewilderment you find it's a shrine dedicated to Mark Zuckerberg")

#endregion

#region elon boss fight
print(elon_musk)
print("After succesfully getting into your dads office you are shocked to see him standing there waiting for you")
print("'You thought I wouldn't know what you are doing?', he says")
print("'Well now you're gonna feel my wrath'")
print("Choose a method to battle your father:")
print("Here is a reminder of your stats: ")
print(player.stats())
while True:
    try:
        battle_choice = int(input("Choose a method of war.\n1.General knowledge quiz battle (benefits from intelligence)\n2.Fist fight (benefits from strength)\n3.Rap battle (benefits from charisma)\n4.Meme war (benefits from autism)\n"))
        print("\n")
        if battle_choice < 1 or battle_choice > 4:
            raise ValueError
        elif battle_choice == 1:
            if player.intelligence > 4:
                print("Due to your epic intelligence, you only need to answer 4/5 questions correctly to win")
                quiz("short")
                winning_ways = "intellect battle"
                break
            else:
                print("Because you're a bit dense, the quiz is longer for you. You must answer 8/10 questions correctly to win")
                quiz("long")
                winning_ways = "intellect battle"
                break
        elif battle_choice == 2:
            print("Fist fight chosen...")
            if player.strength > 4:
                print("With your superior strength you slap your dad up and knock him out cold")
                winning_ways = "fight"
                break
            else:
                game_over("You chose to fight, but you forgot leg day and got rekt by your own dad")
        elif battle_choice == 3:
            print("Rap battle chosen...")
            elons_bars = [
                "Elon: Coulda used protection then you'd never have been born, when I come hard its a lyrical storm.",
                "Elon: I divorced your mum cause she looked like you, you must have got the brains from her since you don't have a clue.",
                "Elon: In this world you are irrelevent, you'll never match up to my gargantuate intelligence.",
                "Elon: You don't own companies, I founded three. I should disinherit you because you don't have the key.",
                "Elon: You're my child and I'm embarrassed, your net worth is like 60 dollars you don't pose a challenge."
            ]
            for i in elons_bars:
                print(i)
                input("Enter a comeback: ")
            if player.charisma > 4:
                print("Due to your superior charisma you destroy your dad in the rap battle")
                winning_ways = "rap battle"
                break
            else:
                game_over("Unfortunately you are not naturally charismatic, and it shows. You lose the rap battle")
        else:
            print("Meme war chosen...")
            if player.autism > 4:
                print("Due to your exceptionally strong autism you have an insane arsenal of memes to bring to the table")
                winning_ways = "meme battle"
                break
            else:
                print("Unfortunately you posess insufficient autistic tendencies for this choice, your meme collection is weak and lacks dankness. try another option.")
    except ValueError:
        print("Please enter an integer from 1-4")
#endregion

#region after defeating elon
print(f"\nAfter defeating elon in a {winning_ways}, he lays there defeated. You decide to kick him as a show of your superiority. As he cowers in fear wimpering you demand answers to his plans. He tells you that his plans were backed by a consortium of poeple included Mark Zuckerberg, Jeff Bazos, Warren Buffet, Vladimir Putin and Bill Gates. \n He eludes that the end goal of the evil billionaire group is to build an ark that orbit's the earth, Elon discloses that project is called 'Hyperloop'. You ask him about the doomsday project titled 'Ion Cannon' and plans to destroy the world. You ask him about where the ion cannon is located but he remains tight lipped another swift kick to the chest and he shouts out 'HERE', 'here?' you ask, Your father prococeeds to divluge that his Tesla company built the ion cannon and his other company SpaceX are currently building the hyperloop in secluded section of the Grand Canyon, in Arizona.\n You quiz your father about the door that you saw earlier under heavy secruity, while laying there defeated he proceeds to comfirm that room is where the ion cannon is located, after further interogation he tell you that the code to launch the ion cannon is '03.05.22' you snatch the keycard from around his neck and give him another swift kick this time to his jaw leaving him unconcious \n After commuting to the door you explain to the guards the reason you have Elon's keycard and are trying to gain entry is that your father wanted you to see inside, you pull rank as the bosses child and they back down allowing you to use the keycard to open the door. Once inside you find no-one else inside, at the centre is a large weapon so large you notice that the base of the ion cannon is built into the ground beneath the foundation of the headquaters 'this is the ion cannon' you think to yourself. As you press the computer terminal located to the right of the room you enter the keycard in the slot underneath the screen titled access key, suddenly the interface opens up showing an AI called B.Z.M.P.G.B that greets you as 'Mr. Musk'. On the screen the true devastation of the plan is revealed the ion cannon was set to be launched upwards then programmed to split into multiple rays landing in 32 different locations around the world major cities, important economic centres, natural resource reseves and areas of dense population all highlighted on the screen. You use the keycard you took from your father to override the cannon and you input the target location to just one place the facility where the hyperloop is being constructed. You press the fire button!")

#endregion

sleep(3)
print(end_credits)
input("Press enter to end the program...")
log("Program end")
quit()